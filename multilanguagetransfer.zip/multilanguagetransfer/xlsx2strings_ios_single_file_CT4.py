#!/usr/bin/env python3

import codecs
import os
import shutil
from xlrd import open_workbook
import jinshan_loadexcel
import time

# 源码地址 https://github.com/shiweibsw/Translation-Tools/blob/master/xlstoxml.py
# 源码地址 https://github.com/CatchZeng/Localizable.strings2Excel#localizablestrings2excel

print("多语言文案生成中，请稍候……")

# 下载excel
jinshan_loadexcel.download()

# 打开excel
workbook = open_workbook('ct4_langugeExcel.xlsx')

# 第一列表示模块下的子模块名
subModuleNameCol = 0

# 第三列表示资源对应的Key
keyCol = 2

# 语言文案从第四列开始
languageStartCol = 3

# 记录子模块名
lastSubModelName = ""

# .lproj文件，需要生成的语言。
languagesDic = {
'zh-CN': 'zh-Hans',
'zh-TW': 'zh-Hant',
'en-US': 'en',
}

moduleNames = ['行情', '图表', '交易', '资讯', '我的', '登录注册', '公共']
# 项目多语言文案所在路径
project_path = '/Users/kinglin/Documents/STL_Projects/CT4'
localizable_path = 'CT4Foundation/CT4Foundation/Language/Localizable'
project_localizable_path = os.path.join(project_path, localizable_path)

for (languageName, value) in languagesDic.items():
    lprojDirName = value + '.lproj'
    localizableFileName = 'Localizable.strings'

    path = os.path.join(os.path.join(project_localizable_path, lprojDirName))
    if not os.path.exists(path):
        os.makedirs(path)
    localizableFilePath = os.path.join(path, localizableFileName)
    if os.path.exists(localizableFilePath):
        # 先删除旧文件
        os.remove(localizableFilePath)
    # 创建打开新文件
    file = codecs.open(localizableFilePath, 'w+', encoding='utf-8')

    update_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    mark_update_time = "/**\n\n 更新日期：%s \n\n **/" % (update_time)
    file.write(mark_update_time)

    sheetList = workbook.sheets()
    for moduleName in moduleNames:
        # 获取对应模块名的sheet表
        filterSheets = list(filter(lambda x: x.name == moduleName, sheetList))
        if len(filterSheets) == 0:
            continue
        sheet = filterSheets[0]
        markText = "// MARK:  =============================================== %s模块 ===============================================" % (sheet.name)
        file.write('\n\n' + markText + '\n\n')

        for col in range(languageStartCol, sheet.ncols):
            title = sheet.cell(0, col).value
            if title != languageName:
                continue
            lanuageCol = col

            for row in range(1, sheet.nrows):
                # 子模块名称
                currentSubModelName = sheet.cell(row, subModuleNameCol).value

                # 当前子模块名不能为""
                if currentSubModelName != "":
                    if lastSubModelName == "":
                        lastSubModelName = currentSubModelName;
                        file.write("\n/// " + lastSubModelName + "\n")
                    else:
                        if lastSubModelName != currentSubModelName:
                            lastSubModelName = currentSubModelName;
                            file.write("\n/// " + lastSubModelName + "\n")

                # 获取文案 key并去除空格
                localizable_key = sheet.cell(row, keyCol).value.strip().replace(" ","")

                # 获取key对应的文案
                if localizable_key != "":
                    localizable_value = sheet.cell(row, lanuageCol).value.__str__()

                    # 替换%s为%@
                    localizable_value = localizable_value.replace('%s', '%@').replace('% s', '%@').replace('% d', '%@')
                    localizable_value = localizable_value.replace('%d', '%@')
                    if languageName == '阿语':
                        localizable_value = localizable_value.replace('٪s', '%@').replace('٪ s', '%@')
                        localizable_value = localizable_value.replace('٪d', '%@').replace('٪ d', '%@')
                        localizable_value = localizable_value.replace('٪@', '%@').replace('٪ @', '%@')
                        localizable_value = localizable_value.replace('@٪', '%@').replace('@ ٪', '%@')
                        localizable_value = localizable_value.replace('s%', '%@').replace('s %', '%@')

                    # 去掉 \r 导致的换行
                    localizable_value = localizable_value.replace('\r','')
                    # 英文""加转义符
                    localizable_value = localizable_value.replace('"', '\\"')
                    # 替换占位符
                    localizable_value = localizable_value.replace("{}", '%@')
                    localizable_value = localizable_value.replace("{0}", '%@')
                    localizable_value = localizable_value.replace("{1}", '%@')

                    if sheet.name == 'iOSInfoPlist':
                        file.write(localizable_key + ' = "' + localizable_value + '";\n')
                    else:
                        file.write('"' + localizable_key + '" = "' + localizable_value + '";\n')

print("多语言导出完成！")






