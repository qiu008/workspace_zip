#!/usr/bin/env python3

import re
import requests

def get(url, path):
    ex_id = re.findall(r'd/(.*?)/edit', url)[0]
    new_url = 'https://docs.google.com/spreadsheets/d/{0}/export?format=xlsx&id={0}'.format(ex_id)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Chromium";v="104", " Not A;Brand";v="99", "Google Chrome";v="104"',
    }
    response = requests.get(new_url, headers=headers)
    with open(path, 'wb') as f:
        f.write(response.content)

def load_xlsx():
    file_url = 'https://docs.google.com/spreadsheets/d/1D5bGct_8oGrGmHT_28lwta4grh_98VUE/edit#gid=2047800876'
    file_path = '/Users/kinglin/Documents/multilanguagetransfer/wikiforexExcel.xlsx'
    get(file_url, file_path)

    print("xlsx文件下载完成！")

if __name__ == '__main__':
    load_xlsx()

