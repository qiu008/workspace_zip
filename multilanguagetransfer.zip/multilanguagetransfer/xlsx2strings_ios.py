#!/usr/bin/env python3

import codecs
import os
from xlrd import open_workbook
import loadxlsx


# 源码地址 https://github.com/shiweibsw/Translation-Tools/blob/master/xlstoxml.py
# 源码地址 https://github.com/CatchZeng/Localizable.strings2Excel#localizablestrings2excel

# 下载excel
loadxlsx.load_xlsx()

# 打开excel
workbook = open_workbook('wikiforexExcel.xlsx')

# 第二栏表示模块下的子模块名
subModuleNameCol = 1

# 第三列表示资源对应的Key
keyCol = 2

# 语言文案从第四列开始
languageStartCol = 3

# 语言标题所在的row
languageTitleRow = 0

# 文案开始的row
startRow = 1

# 记录子模块名
lastSubModelName = ""

# .lproj文件，需要生成的语言。
languagesDic = {
'简体中文': 'zh-Hans',
'繁体中文': 'zh-Hant',
'英语': 'en',
'越南语': 'vi',
'阿语': 'ar',
'泰语': 'th'
}


# 添加字符串
for sheet in workbook.sheets():
    for col in range(languageStartCol, sheet.ncols):
        iosStringsName = 'Localizable.strings'
        languageTitle = sheet.cell(languageTitleRow, col).value
        if languageTitle not in languagesDic.keys():
            continue
        lproFileName = languagesDic[languageTitle] + '.lproj'

        path = os.path.join(os.path.join("lproj/wikiforex-module", sheet.name), lproFileName)
        if not os.path.exists(path):
            os.makedirs(path)
        localizableFilePath = os.path.join(path, iosStringsName)
        if os.path.exists(localizableFilePath):
            # 先删除旧文件
            os.remove(localizableFilePath)
        # 创建打开新文件
        file = codecs.open(localizableFilePath, 'w+', encoding='utf-8')
        for row_index in range(startRow, sheet.nrows):

            # 区分子模块
            currentSubModelName = sheet.cell(row_index, subModuleNameCol).value;

            # 当前子模块名不能为""
            if currentSubModelName != "":
                if lastSubModelName == "":
                    lastSubModelName = currentSubModelName;
                    file.write("\n/// " + lastSubModelName + "\n")
                else:
                    if lastSubModelName != currentSubModelName:
                        lastSubModelName = currentSubModelName;
                        file.write("\n/// " + lastSubModelName + "\n")
            result_placeholder = sheet.cell(row_index, keyCol).value.strip()
            result_placeholder = result_placeholder.replace(" ","")

            if result_placeholder != "":
                result_content = sheet.cell(row_index, col).value.__str__()

                # 替换%s\%d为%@
                result_content = result_content.replace('%s', '%@').replace('%d', '%@').replace('% d', '%@')
                if languageTitle == '阿语':
                        result_content = result_content.replace('٪s', '%@').replace('٪ s', '%@')
                        result_content = result_content.replace('٪d', '%@').replace('٪ d', '%@')
                        result_content = result_content.replace('٪@', '%@').replace('٪ @', '%@')
                        result_content = result_content.replace('@٪', '%@').replace('@ ٪', '%@')

                # 去掉 \r 导致的换行
                result_content = result_content.replace('\r','')
                # 英文""加转义符
                result_content = result_content.replace('"', '\\"')
                # 替换占位符
                result_content = result_content.replace("{}", '%@')
                result_content = result_content.replace("{0}", '%@')
                result_content = result_content.replace("{1}", '%@')

                if sheet.name == 'iOSInfoPlist':
                    file.write(result_placeholder + ' = "' + result_content + '";\n')
                else:
                    file.write('"' + result_placeholder + '" = "' + result_content + '";\n');

print("lproj文件导出完成！")


