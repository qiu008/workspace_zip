# -*- coding: utf-8 -*-
import re
import json
import requests

cookie = 'docset_svg_info=%7B%22active_sheet%22%3A%22%E6%88%91%E7%9A%84%22%2C%22topleft_cell%22%3A%7B%22row%22%3A64%2C%22col%22%3A0%7D%2C%22dpi%22%3A1%2C%22w%22%3A2560%2C%22h%22%3A1055%2C%22device_type%22%3A%22pc%22%7D; swi_acc_redirect_limit=0; lang=zh-CN; weboffice_device_id=c16ae659d596493e728afbd2cc66fee0; visitorid=1760324371; weboffice_cdn=21; wpsua=V1BTVUEvMS4wICh3ZWIta2RvY3M6Q2hyb21lXzExOS4wLjAuMDsgbWFjOk9TIFg7IGJxbkFLYzJDVFdlYlc3dVlFSjgxanc9PTpUV0ZqYVc1MGIzTm9JQ0E9KSBNYWNpbnRvc2gv; csrf=mma2Hzn3aQK5RbNQicHn4hjwthkwW7wi; wps_endcloud=1; showNewVersionTime=1699865039794; wps_sid=V02S9E9boqcDuj8-kY9hUkT9-xGoG_800a8f6152002bb592a1; reloginsucc=1; env=prod-1; region=hw'

def get_id(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Cookie': cookie
    }
    response = requests.get(url, headers=headers)
    conn_id = re.findall(r'"conn_id":"(.*?)","user_id"', response.text)[0]
    file_id = re.findall(r'"file":\{"id":"(.*?)","name', response.text)[0]
    return conn_id, file_id


def download():
    url = 'https://www.kdocs.cn/l/ccnt8oCJY6jE'
    output_path = '/Users/kinglin/Documents/multilanguagetransfer/ct4_langugeExcel.xlsx'

    conn_id, file_id = get_id(url)
    new_url = 'https://www.kdocs.cn/api/v3/office/file/{0}/download?options=%7B%7D&clientId={1}&format=xlsx'.format(file_id, conn_id)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Cookie': cookie
    }
    response = requests.get(new_url, headers=headers)
    result = json.loads(response.text)
    download_url = result['download_url']
    ex_response = requests.get(download_url, headers=headers)
    with open(output_path, 'wb') as f:
        f.write(ex_response.content)
